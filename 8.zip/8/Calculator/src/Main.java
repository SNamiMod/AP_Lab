/**
 * prooooooo calculator :)))
 * @author Seyed Nami Modarressi
 * @version 1.5
 * @since 2020
 */
public class Main {

    public static void main(String[] args) {

        UI calculator = new UI();

    }
}
