/**
 * design and calculate
 * @author Seyed Nami Modarressi
 * @version 1.5
 * @since 2020
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class UI{

    private JFrame calc;
    private JTabbedPane mode;
    private JPanel simple;
    private JPanel pro;
    private JTextField calcText;
    private JMenuBar menu;

    // buttons for simple mode
    private JButton ACSimple;
    private JButton zeroSimple;
    private JButton oneSimple;
    private JButton twoSimple;
    private JButton threeSimple;
    private JButton fourSimple;
    private JButton fiveSimple;
    private JButton sixSimple;
    private JButton sevenSimple;
    private JButton eightSimple;
    private JButton nineSimple;
    private JButton backSimple;
    private JButton percentSimple;
    private JButton divisionSimple;
    private JButton multiplicationSimple;
    private JButton subtractSimple;
    private JButton addSimple;
    private JButton equalSimple;
    private JButton dotSimple;
    
    // buttons for pro mode
    private JButton clearPro;
    private JButton backPro;
    private JButton percentPro;
    private JButton divisionPro;
    private JButton multiplicationPro;
    private JButton subtractPro;
    private JButton addPro;
    private JButton equalPro;
    private JButton onePro;
    private JButton twoPro;
    private JButton threePro;
    private JButton fourPro;
    private JButton fivePro;
    private JButton sixPro;
    private JButton sevenPro;
    private JButton eightPro;
    private JButton ninePro;
    private JButton zeroPro;
    private JButton dotPro;
    private JButton shift;
    private JButton sqrt;
    private JButton sin;
    private JButton tan;
    private JButton exp;

    /**
     * create calculator UI
     */
    public UI() {
        menu = new JMenuBar();
        calc = new JFrame("Calculator");
        calc.setLocationRelativeTo(null);
        calc.setSize(350, 400);
        calc.setLayout(new BorderLayout());
        calc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mode = new JTabbedPane();
        simple = new JPanel(new GridLayout(5, 4 ));
        pro = new JPanel(new GridLayout(5, 5));
        screen();
        basicKey();
        ProKey();
        mode.add("Basic", simple);
        mode.add("Pro", pro);
        calc.add(mode);

        JMenu option = new JMenu("Option");
        option.setMnemonic('M');
        JMenuItem copy = new JMenuItem("Copy result");
        JMenuItem exit = new JMenuItem("Exit");
        option.add(copy);
        option.add(exit);

        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        copy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(calc, "Result is "+calcText.getText() , "Result",JOptionPane.PLAIN_MESSAGE);
            }
        });

        exit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, ActionEvent.CTRL_MASK));
        copy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));

        menu.add(option);

        calc.setJMenuBar(menu);
        show();
    }

    /**
     * add text field to calculator
     */
    public void screen() {
        calcText = new JTextField();
        calcText.setEditable(true);
        calc.add(calcText, BorderLayout.NORTH);
    }

    /**
     * add keys to basic mode
     */
    public void basicKey() {
        ACSimple = new JButton("AC");
        ACSimple.setForeground(Color.RED);
        ACSimple.setToolTipText("Clear text");
        ACSimple.addMouseListener(new MouseHandler());
        simple.add(ACSimple);

        backSimple = new JButton("Delete");
        backSimple.setForeground(Color.BLUE);
        backSimple.setToolTipText("Delete last character");
        backSimple.addMouseListener(new MouseHandler());
        simple.add(backSimple);


        percentSimple = new JButton("%");
        percentSimple.setForeground(Color.BLUE);
        percentSimple.setToolTipText("percent");
        percentSimple.addMouseListener(new MouseHandler());
        simple.add(percentSimple);

        multiplicationSimple = new JButton("*");
        multiplicationSimple.setForeground(Color.BLUE);
        multiplicationSimple.addMouseListener(new MouseHandler());
        simple.add(multiplicationSimple);


        sevenSimple = new JButton("7");
        sevenSimple.addMouseListener(new MouseHandler());
        simple.add(sevenSimple);

        eightSimple = new JButton("8");
        eightSimple.addMouseListener(new MouseHandler());
        simple.add(eightSimple);

        nineSimple = new JButton("9");
        nineSimple.addMouseListener(new MouseHandler());
        simple.add(nineSimple);

        divisionSimple = new JButton("/");
        divisionSimple.setForeground(Color.BLUE);
        divisionSimple.addMouseListener(new MouseHandler());
        simple.add(divisionSimple);

        fourSimple = new JButton("4");
        fourSimple.addMouseListener(new MouseHandler());
        simple.add(fourSimple);

        fiveSimple = new JButton("5");
        fiveSimple.addMouseListener(new MouseHandler());
        simple.add(fiveSimple);

        sixSimple = new JButton("6");
        sixSimple.addMouseListener(new MouseHandler());
        simple.add(sixSimple);

        addSimple = new JButton("+");
        addSimple.setForeground(Color.BLUE);
        addSimple.addMouseListener(new MouseHandler());
        simple.add(addSimple);

        oneSimple = new JButton("1");
        oneSimple.addMouseListener(new MouseHandler());
        simple.add(oneSimple);

        twoSimple = new JButton("2");
        twoSimple.addMouseListener(new MouseHandler());
        simple.add(twoSimple);

        threeSimple = new JButton("3");
        threeSimple.addMouseListener(new MouseHandler());
        simple.add(threeSimple);

        subtractSimple = new JButton("-");
        subtractSimple.setForeground(Color.BLUE);
        subtractSimple.setToolTipText("subtract");
        subtractSimple.addMouseListener(new MouseHandler());
        simple.add(subtractSimple);

        zeroSimple = new JButton("0");
        zeroSimple.addMouseListener(new MouseHandler());
        simple.add(zeroSimple);

        dotSimple = new JButton(".");
        dotSimple.addMouseListener(new MouseHandler());
        simple.add(dotSimple);

        JButton tempSimple = new JButton("");
        tempSimple.setVisible(false);
        simple.add(tempSimple);

        equalSimple = new JButton("=");
        equalSimple.setForeground(Color.RED);
        equalSimple.addMouseListener(new MouseHandler());
        simple.add(equalSimple);
    }

    /**
     * add pro keys to pro mode
     */
    public void ProKey() {
        shift = new JButton("SHIFT");
        shift.setToolTipText("Press Shift to change buttons");
        shift.addMouseListener(new MouseHandler());
        shift.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (sin.getText().equals("sin")){
                    sin.setText("cos");
                }else {
                    sin.setText("sin");
                }
                if (tan.getText().equals("tan")){
                    tan.setText("cot");
                }else {
                    tan.setText("tan");
                }
                if (exp.getText().equals("exp")){
                    exp.setText("ln");
                }else {
                    exp.setText("exp");
                }
            }
        });
        pro.add(shift);

        clearPro = new JButton("AC");
        clearPro.setForeground(Color.RED);
        clearPro.setToolTipText("Clear text");
        clearPro.addMouseListener(new MouseHandler());
        pro.add(clearPro);

        backPro = new JButton("Delete");
        backPro.setForeground(Color.BLUE);
        backPro.setToolTipText("delete last character");
        backPro.addMouseListener(new MouseHandler());
        pro.add(backPro);

        percentPro = new JButton("%");
        percentPro.setForeground(Color.BLUE);
        percentPro.setToolTipText("percent");
        percentPro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calcText.setText(calcText.getText()+'%');
            }
        });
        pro.add(percentPro);

        divisionPro = new JButton("/");
        divisionPro.setForeground(Color.BLUE);
        divisionPro.addMouseListener(new MouseHandler());
        pro.add(divisionPro);

        sqrt = new JButton("√");
        sqrt.setToolTipText("sqrt");
        sqrt.addMouseListener(new MouseHandler());
        sqrt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calcText.setText(calcText.getText()+'√');
            }
        });
        pro.add(sqrt);

        sevenPro = new JButton("7");
        sevenPro.addMouseListener(new MouseHandler());
        pro.add(sevenPro);

        eightPro = new JButton("8");
        eightPro.addMouseListener(new MouseHandler());
        pro.add(eightPro);

        ninePro = new JButton("9");
        ninePro.addMouseListener(new MouseHandler());
        pro.add(ninePro);

        multiplicationPro = new JButton("*");
        multiplicationPro.addMouseListener(new MouseHandler());
        multiplicationPro.setForeground(Color.BLUE);
        pro.add(multiplicationPro);

        sin = new JButton("sin");
        sin.setToolTipText("Press shift to use cos");
        sin.addMouseListener(new MouseHandler());
        pro.add(sin);

        fourPro = new JButton("4");
        fourPro.addMouseListener(new MouseHandler());
        pro.add(fourPro);

        fivePro = new JButton("5");
        fivePro.addMouseListener(new MouseHandler());
        pro.add(fivePro);

        sixPro = new JButton("6");
        sixPro.addMouseListener(new MouseHandler());
        pro.add(sixPro);

        subtractPro = new JButton("-");
        subtractPro.setForeground(Color.BLUE);
        subtractPro.setToolTipText("Subtract");
        subtractPro.addMouseListener(new MouseHandler());
        pro.add(subtractPro);

        tan = new JButton("tan");
        tan.setToolTipText("Press shift to use cot");
        tan.addMouseListener(new MouseHandler());
        pro.add(tan);

        onePro = new JButton("1");
        onePro.addMouseListener(new MouseHandler());
        pro.add(onePro);

        twoPro = new JButton("2");
        twoPro.addMouseListener(new MouseHandler());
        pro.add(twoPro);

        threePro = new JButton("3");
        threePro.addMouseListener(new MouseHandler());
        pro.add(threePro);

        addPro = new JButton("+");
        addPro.setForeground(Color.BLUE);
        addPro.addMouseListener(new MouseHandler());
        pro.add(addPro);

        exp = new JButton("exp");
        exp.setToolTipText("Press shift to use log");
        exp.addMouseListener(new MouseHandler());
        pro.add(exp);

        zeroPro = new JButton("0");
        zeroPro.addMouseListener(new MouseHandler());
        pro.add(zeroPro);

        dotPro = new JButton(".");
        dotPro.addMouseListener(new MouseHandler());
        pro.add(dotPro);

        JButton tempPro = new JButton("");
        tempPro.setVisible(false);
        pro.add(tempPro);

        equalPro = new JButton("=");
        equalPro.setForeground(Color.red);
        equalPro.addMouseListener(new MouseHandler());
        pro.add(equalPro);
    }

    /**
     * show calculator
     */
    public void show() {
        calc.setVisible(true);
    }

    /**
     * calculate
     * @param text text of operations
     */
    public void arithmetic(String text)
    {
        text = text.replaceAll(" ", "");
        double a;
        double b;
        double result;
        if (text.contains("+"))
        {
            a = Double.parseDouble(text.substring(0, text.indexOf('+')));
            b = Double.parseDouble(text.substring(text.indexOf('+') + 1, text.length()));
            result = a + b;
            calcText.setText(""+result);
        }
        else if (text.contains("%"))
        {
            a = Double.parseDouble(text.substring(0, text.indexOf('%')));
            b = Double.parseDouble(text.substring(text.indexOf('%') + 1, text.length()));
            result = (a * b / 100);
            calcText.setText(""+ result);
        }
        else if (text.contains("-"))
        {
            a = Double.parseDouble(text.substring(0, text.indexOf('-')));
            b = Double.parseDouble(text.substring(text.indexOf('-') + 1, text.length()));
            result = a - b;
            calcText.setText(""+result);
        }
        else if (text.contains("*"))
        {
            a = Double.parseDouble(text.substring(0, text.indexOf('*')));
            b = Double.parseDouble(text.substring(text.indexOf('*') + 1, text.length()));
            result = a * b;
            calcText.setText(""+ result);
        }
        else if (text.contains("/"))
        {
            a = Double.parseDouble(text.substring(0, text.indexOf('/')));
            b = Double.parseDouble(text.substring(text.indexOf('/') + 1, text.length()));
            if (b != 0)
            {
                result = a / b;
                calcText.setText(""+result);
            }
            else
            {
                calcText.setText("cant do operation");
            }
        }
        else if (text.contains("exp"))
        {
            a = Double.parseDouble(text.substring(0, text.indexOf("exp")));
            result = Math.exp(a);
            calcText.setText(""+result);
        }
        else if (text.contains("sin"))
        {
            a = Double.parseDouble(text.substring(0, text.indexOf("sin")));
            result = Math.sin(a);
            calcText.setText(""+result);
        }
        else if (text.contains("cos"))
        {
            a = Double.parseDouble(text.substring(0, text.indexOf("cos")));
            result = Math.cos(a);
            calcText.setText(""+result);
        }
        else if (text.contains("tan"))
        {
            a = Double.parseDouble(text.substring(0, text.indexOf("tan")));
            result = Math.tan(a);
            calcText.setText(""+result);
        }
        else if (text.contains("cot"))
        {
            a = Double.parseDouble(text.substring(0, text.indexOf("cot")));
            result = 1/Math.tan(a);
            calcText.setText(""+result);
        }
        else if (text.contains("ln"))
        {
            a = Double.parseDouble(text.substring(0, text.indexOf("ln")));
            result = Math.log(a);
            calcText.setText(""+result);
        }
        else if (text.contains("√"))
        {
            a = Double.parseDouble(text.substring(0, text.indexOf("√")));
            result = Math.sqrt(a);
            calcText.setText(""+result);
        }
        else
        {
            calcText.setText("");
        }
    }

   public class MouseHandler extends MouseAdapter {
       public void mouseClicked(MouseEvent e) {
           if (e.getSource().equals(ACSimple) || e.getSource().equals(clearPro)) {
               calcText.setText("");
           } else if (e.getSource().equals(backSimple) || e.getSource().equals(backPro)) {
               calcText.setText(calcText.getText().substring(0, calcText.getText().length() - 1));
           } else if (e.getSource().equals(percentSimple) || e.getSource().equals(percentPro)) {
               calcText.setText(calcText.getText() + "%");
           } else if (e.getSource().equals(divisionSimple) || e.getSource().equals(divisionPro)) {
               calcText.setText(calcText.getText() + "/");
           } else if (e.getSource().equals(multiplicationSimple) || e.getSource().equals(multiplicationPro)) {
               calcText.setText(calcText.getText() + "*");
           } else if (e.getSource().equals(subtractSimple) || e.getSource().equals(subtractPro)) {
               calcText.setText(calcText.getText() + "-");
           } else if (e.getSource().equals(addSimple) || e.getSource().equals(addPro)) {
               calcText.setText(calcText.getText() + "+");
           } else if (e.getSource().equals(equalSimple) || e.getSource().equals(equalPro)) {
               arithmetic(calcText.getText());
           } else if (e.getSource().equals(oneSimple) || e.getSource().equals(onePro)) {
               calcText.setText(calcText.getText() + "1");
           } else if (e.getSource().equals(twoSimple) || e.getSource().equals(twoPro)) {
               calcText.setText(calcText.getText() + "2");
           } else if (e.getSource().equals(threeSimple) || e.getSource().equals(threePro)) {
               calcText.setText(calcText.getText() + "3");
           } else if (e.getSource().equals(fourSimple) || e.getSource().equals(fourPro)) {
               calcText.setText(calcText.getText() + "4");
           } else if (e.getSource().equals(fiveSimple) || e.getSource().equals(fivePro)) {
               calcText.setText(calcText.getText() + "5");
           } else if (e.getSource().equals(sixSimple) || e.getSource().equals(sixPro)) {
               calcText.setText(calcText.getText() + "6");
           } else if (e.getSource().equals(sevenSimple) || e.getSource().equals(sevenPro)) {
               calcText.setText(calcText.getText() + "7");
           } else if (e.getSource().equals(eightSimple) || e.getSource().equals(eightPro)) {
               calcText.setText(calcText.getText() + "8");
           } else if (e.getSource().equals(nineSimple) || e.getSource().equals(ninePro)) {
               calcText.setText(calcText.getText() + "9");
           } else if (e.getSource().equals(zeroSimple) || e.getSource().equals(zeroPro)) {
               calcText.setText(calcText.getText() + "0");
           } else if (e.getSource().equals(dotSimple) || e.getSource().equals(dotPro)) {
               calcText.setText(calcText.getText() + ".");
           } else if (e.getSource().equals(sqrt)) {
               if (sqrt.getText().equals("sqrt")) {
                   calcText.setText(calcText.getText() + "sqrt");
               }

           } else if (e.getSource().equals(sin)) {
               if (sin.getText().equals("sin")) {
                   calcText.setText(calcText.getText() + "sin");
               } else {
                   calcText.setText(calcText.getText() + "cos");
               }
           } else if (e.getSource().equals(tan)) {
               if (tan.getText().equals("tan")) {
                   calcText.setText(calcText.getText() + "tan");
               } else {
                   calcText.setText(calcText.getText() + "cot");
               }
           } else if (e.getSource().equals(exp)) {
               if (exp.getText().equals("exp")) {
                   calcText.setText(calcText.getText() + "exp");
               } else {
                   calcText.setText(calcText.getText() + "ln");
               }
           }

       }
   }
}