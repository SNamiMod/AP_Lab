import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner get_number = new Scanner(System.in);

        int first_number = get_number.nextInt();
        int second_number = get_number.nextInt();
        int flag = 0;
        int min_number = (first_number > second_number)?second_number:first_number;

        for (int i = 2 ; i < min_number ; i++){

            if (first_number % i == 0 && second_number % i == 0){

                System.out.print("No");
                flag = 1;

            }

        }
        if (flag == 0){

            System.out.print("Yes");

        }

    }
}
