public class Problem3{
    public static void main(String[] args){

          String input_string = "Salam !";

          for (char ch:input_string.toCharArray()){

              System.out.println(ch);

          }
    }
}
