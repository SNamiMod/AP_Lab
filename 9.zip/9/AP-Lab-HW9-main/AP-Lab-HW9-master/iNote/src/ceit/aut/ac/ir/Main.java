/**
 * main part of program
 * @author Seyed Nami Modarressi
 * @Version 1.0
 * @since 2020
 */
package ceit.aut.ac.ir;

import ceit.aut.ac.ir.gui.CFrame;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {

        CFrame frame = new CFrame("iNote");
        frame.setVisible(true);
        frame.setSize(500, 500);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    }
}
