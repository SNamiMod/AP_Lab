/**
 * this is the music class base og music player
 * every music has singer / address / release date
 * @author Seyed Nami Modarressi
 * @version v1
 */
public class Music {

    private String address;
    private String singer;
    private int releaseDate;

    public Music(String m , String s , int n){
        address = m;
        singer = s;
        releaseDate = n;
    }
    /**
     * set address of music
     * @param address address we want to set
     */
    public void setAddress(String address){
        this.address=address;
    }
    /**
     * set singer of music
     * @param singer singer we want to set
     */
    public void setSinger(String singer){
        this.singer=singer;
    }
    /**
     * set release date of music
     * @param date release date we want to set
     */
    public void setReleaseDate(int date){
        releaseDate = date;
    }
    /**
     * get address of song
     * @return address as string
     */
    public String getAddress(){
        return address;
    }

    /**
     * get singer of song
     * @return singer as string
     */
    public String getSinger(){
        return singer;
    }

    /**
     * get release date of song
     * @return date as int
     */
    public int getReleaseDate(){
        return releaseDate;
    }

}
