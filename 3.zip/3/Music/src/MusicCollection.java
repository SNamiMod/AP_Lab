import java.util.ArrayList;
import java.util.Iterator;

/**
 * A class to hold details of audio files.
 *
 * @author David J. Barnes and Michael K�lling / Seyed Nami Modarressi
 * @version 2011.07.31(v2)
 */
public class MusicCollection
{
    // An ArrayList for storing the file names of music files.
    private ArrayList<Music> musics = new ArrayList<Music>();
    private ArrayList<Music> favoriteMusics = new ArrayList<Music>();
    // A player for the music files.
    private MusicPlayer player;

    /**
     * Create a MusicCollection
     */
    public MusicCollection()
    {
        // Hello :)
    }
    /**
     * searching in songs
     * @param s singer or address of song
     * @return index of song
     */
    public int findIndex(String s){
        int index=0;
        boolean flag=false;
        for(Music m:musics){
            if (m.getSinger().equals(s) || m.getAddress().equals(s)){
                flag=true;
                return index;
            }
            index++;
        }
        return -1;
    }

    /**
     * get music from files
     * @param index The file we want.
     * @return music
     */
    public Music getSong(int index){
        return musics.get(index);
    }

    /**
     * Add a file to the collection.
     * @param music The file to be added.
     */
    public void addFile(Music music)
    {
        musics.add(music);
    }
    /**
     * Add a file to favorite musics.
     * @param name name of The file to be added.
     */
    public void addFavoriteFile(String name)
    {
        boolean flag=false;
        String singer = "";
        int date = 0;

        for (Music m :musics){

            if (m.getAddress().equals(name)){
                flag = true;
                date = m.getReleaseDate();
                singer = m.getSinger();
                break;
            }
        }

        if (flag == false){
            System.out.println("Not Found");
        }else {
            favoriteMusics.add(new Music(name,singer,date));
        }

    }

    /**
     * Return the number of files in the collection.
     * @return The number of files in the collection.
     */
    public int getNumberOfFiles()
    {
        return musics.size();
    }

    /**
     * List a file from the collection.
     * @param index The index of the file to be listed.
     */
    public void listFile(int index)
    {
        System.out.println("Address :");
        System.out.println(musics.get(index).getAddress());
        System.out.println("Singer :");
        System.out.println(musics.get(index).getSinger());
        System.out.println("Realse Date :");
        System.out.println(musics.get(index).getReleaseDate());
        System.out.println("**********");
    }

    /**
     * Show a list of all the files in the collection.
     */
    public void listAllFiles()
    {
        int index = 0;
        for (Music sample:musics){
            listFile(index);
            index++;
        }
    }
    /**
     * delete from favorite collection
     * @param sample singer or song's address
     */
    public void deleteFavoriteFile(String sample){
        Iterator iter = favoriteMusics.iterator();
        boolean flag = false;
        Music m;
        while (iter.hasNext()) {
            m = (Music) iter.next();
            if (m.getAddress().equals(sample) || m.getSinger().equals(sample)) {
                iter.remove();
                flag = true;
            }

            if (flag == false){
                System.out.println("Not Found!");
            }

        }
    }
    /**
     * searching in favorite songs and print information
     * @param sample singer or address of song
     */
    public void findFavoriteFile(String sample){
        int index = 0;
        boolean flag = false;
        for (Music m:favoriteMusics){
            if (m.getAddress().equals(sample) || m.getSinger().equals(sample)){
                flag=true;
                System.out.println("Address :");
                System.out.println(favoriteMusics.get(index).getAddress());
                System.out.println("Singer :");
                System.out.println(favoriteMusics.get(index).getSinger());
                System.out.println("Realse Date :");
                System.out.println(favoriteMusics.get(index).getReleaseDate());
                System.out.println("**********");

            }
            index++;
        }

        if (flag == false){
            System.out.println("Not Found");
        }
    }
    /**
     * searching in songs and print information
     * @param sample singer or address of song
     */
    public void findMusic(String sample){
        int index = 0;
        boolean flag = false;
        for (Music m:musics){
            if (m.getAddress().equals(sample) || m.getSinger().equals(sample)){
                flag=true;
                System.out.println("Address :");
                System.out.println(musics.get(index).getAddress());
                System.out.println("Singer :");
                System.out.println(musics.get(index).getSinger());
                System.out.println("Realse Date :");
                System.out.println(musics.get(index).getReleaseDate());
                System.out.println("**********");

            }
            index++;
        }

        if (flag == false){
            System.out.println("Not Found");
        }
    }


    /**
     * show all favorite musics
     */
    public void listFavoriteFiles()
    {
        int index = 0;
        for (Music sample:favoriteMusics){
            listFile(index);
            index++;
        }
    }

    /**
     * Remove a file from the collection.
     * @param sample the singer or song's name
     */

    public void deleteFile(String sample) {
        Iterator iter = musics.iterator();
        boolean flag = false;
        Music m;
        while (iter.hasNext()) {
             m = (Music) iter.next();
            if (m.getAddress().equals(sample) || m.getSinger().equals(sample)) {
                iter.remove();
                flag = true;
            }

            if (flag == false){
                System.out.println("Not Found!");
            }

        }
    }

    /**
     * Start playing a file in the collection.
     * Use stopPlaying() to stop it playing.
     * @param index The index of the file to be played.
     */
    public void startPlaying(int index)
    {
        player.startPlaying(musics.get(index));
    }

    /**
     * Stop the player.
     */
    public void stopPlaying()
    {
        player.stop();
    }

}