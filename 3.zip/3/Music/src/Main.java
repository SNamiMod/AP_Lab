import java.util.Scanner;
/**
 *this is the main class of program
 * you can call all methods here
 *
 * @author Seyed Nami Modarressi
 * @version 2011.07.31(v2)
 */
public class Main {

    public static void main(String[] args) {

        String temp;
        MusicCollection pop = new MusicCollection();
        MusicCollection jazz = new MusicCollection();
        MusicCollection rock = new MusicCollection();
        MusicCollection country = new MusicCollection();
        MusicPlayer player = new MusicPlayer();
        int choice=0;
        Scanner input = new Scanner(System.in);

        while(choice!=12){

            System.out.println("1)Add Song");
            System.out.println("2)Delete song");
            System.out.println("3)Add song to favorite");
            System.out.println("4)Delete song from favorite");
            System.out.println("5)Get number of songs");
            System.out.println("6)Find song");
            System.out.println("7)Find song in favorite");
            System.out.println("8)Show favorite songs");
            System.out.println("9)Show all songs");
            System.out.println("10)Play song");
            System.out.println("11)Stop playing");
            choice = input.nextInt();
            System.out.println("----------");

            switch (choice){

                case 1:
                    String add_genre;
                    String add_name;
                    String add_singer;
                    int add_release;
                    System.out.println("Enter song's genre (pop / jazz / rock / country) :");
                    temp = input.nextLine();
                    add_genre = input.nextLine();
                    System.out.println("Enter song's name :");
                    add_name = input.nextLine();
                    System.out.println("Enter singer :");
                    add_singer=input.nextLine();
                    System.out.println("Enter release Date (year) :");
                    add_release = input.nextInt();

                    if (add_genre.equals("pop")){
                        pop.addFile(new Music(add_name,add_singer,add_release));
                    }
                    if (add_genre.equals("jazz")){
                        jazz.addFile(new Music(add_name,add_singer,add_release));
                    }
                    if (add_genre.equals("rock")){
                        rock.addFile(new Music(add_name,add_singer,add_release));
                    }
                    if (add_genre.equals("country")){
                        country.addFile(new Music(add_name,add_singer,add_release));
                    }
                    System.out.println("Done");
                    break;
                case 2:
                    String delete;
                    String delete_genre;
                    System.out.println("Enter song's genre (pop / jazz / rock / country) :");
                    temp = input.nextLine();
                    delete_genre = input.nextLine();
                    System.out.println("Enter song's name to delete song or enter singer to delete singer's songs :");
                    delete = input.nextLine();
                    if (delete_genre.equals("pop")){
                        pop.deleteFile(delete);
                    }
                    if (delete_genre.equals("jazz")){
                        jazz.deleteFile(delete);
                    }
                    if (delete_genre.equals("rock")){
                        rock.deleteFile(delete);
                    }
                    if (delete_genre.equals("country")){
                        country.deleteFile(delete);
                    }
                    System.out.println("Done");
                    break;
                case 3:
                    String add_favorite_genre;
                    String add_favorite_name;
                    System.out.println("Enter song's genre (pop / jazz / rock / country) :");
                    temp = input.nextLine();
                    add_favorite_genre = input.nextLine();
                    System.out.println("Enter song's name :");
                    add_favorite_name = input.nextLine();

                    if (add_favorite_genre.equals("pop")){
                        pop.addFavoriteFile(add_favorite_name);
                    }
                    if (add_favorite_genre.equals("jazz")){
                        jazz.addFavoriteFile(add_favorite_name);
                    }
                    if (add_favorite_genre.equals("rock")){
                        rock.addFavoriteFile(add_favorite_name);
                    }
                    if (add_favorite_genre.equals("country")){
                        country.addFavoriteFile(add_favorite_name);
                    }
                    System.out.println("Done");
                    break;
                case 4:
                    String favorite_delete;
                    String delete_favorite_genre;
                    System.out.println("Enter song's genre (pop / jazz / rock / country) :");
                    temp = input.nextLine();
                    delete_favorite_genre = input.nextLine();
                    System.out.println("Enter song's name to delete song or enter singer to delete singer's songs    :");
                    favorite_delete = input.nextLine();
                    if (delete_favorite_genre.equals("pop")){
                       pop.deleteFavoriteFile(favorite_delete);
                    }
                    if (delete_favorite_genre.equals("jazz")){
                        jazz.deleteFavoriteFile(favorite_delete);
                    }
                    if (delete_favorite_genre.equals("rock")){
                        rock.deleteFavoriteFile(favorite_delete);
                    }
                    if (delete_favorite_genre.equals("country")){
                        country.deleteFavoriteFile(favorite_delete);
                    }
                    System.out.println("Done");
                    break;
                case 5:
                    String genre_number;
                    System.out.println("Enter song's genre (pop / jazz / rock / country) :");
                    temp = input.nextLine();
                    genre_number = input.nextLine();
                    if (genre_number.equals("pop")){
                        System.out.println(pop.getNumberOfFiles());
                    }
                    if (genre_number.equals("jazz")){
                        System.out.println(jazz.getNumberOfFiles());
                    }
                    if (genre_number.equals("rock")){
                        System.out.println(rock.getNumberOfFiles());
                    }
                    if (genre_number.equals("country")){
                        System.out.println(country.getNumberOfFiles());
                    }

                    break;
                case 6:
                    String p;
                    String genre_find;
                    System.out.println("Enter song's genre (pop / jazz / rock / country) :");
                    temp = input.nextLine();
                    genre_find = input.nextLine();
                    System.out.println("Enter song's name or singer :");
                    p = input.nextLine();

                    if (genre_find.equals("pop")){
                        pop.findMusic(p);
                    }
                    if (genre_find.equals("jazz")){
                        jazz.findMusic(p);
                    }
                    if (genre_find.equals("rock")){
                        rock.findMusic(p);
                    }
                    if (genre_find.equals("country")){
                        country.findMusic(p);
                    }
                    break;
                case 7:
                    String s;
                    String genre_find_favorit;
                    System.out.println("Enter song's genre (pop / jazz / rock / country) :");
                    temp = input.nextLine();
                    genre_find_favorit = input.nextLine();
                    System.out.println("Enter song's name or singer :");
                    s = input.nextLine();

                    if (genre_find_favorit.equals("pop")){
                        pop.findFavoriteFile(s);
                    }
                    if (genre_find_favorit.equals("jazz")){
                        jazz.findFavoriteFile(s);
                    }
                    if (genre_find_favorit.equals("rock")){
                        rock.findFavoriteFile(s);
                    }
                    if (genre_find_favorit.equals("country")){
                        country.findFavoriteFile(s);
                    }
                    break;
                case 8:
                    System.out.println("POP :");
                    pop.listFavoriteFiles();
                    System.out.println("JAZZ :");
                    jazz.listFavoriteFiles();
                    System.out.println("ROCK :");
                    rock.listFavoriteFiles();
                    System.out.println("COUNTRY :");
                    country.listFavoriteFiles();
                    break;
                case 9:
                    System.out.println("POP :");
                    pop.listAllFiles();
                    System.out.println("JAZZ :");
                    jazz.listAllFiles();
                    System.out.println("ROCK :");
                    rock.listAllFiles();
                    System.out.println("COUNTRY :");
                    country.listAllFiles();
                    break;
                case 10:
                    String sample;
                    String genre;
                    System.out.println("Enter song's name :");
                    temp = input.nextLine();
                    sample=input.nextLine();
                    System.out.println("Enter song's genre (pop / jazz / rock / country) :");
                    genre=input.nextLine();

                    if(genre.equals("pop")){
                        player.startPlaying(pop.getSong(pop.findIndex(sample)));
                    }

                    if(genre.equals("jazz")){
                        player.startPlaying(jazz.getSong(jazz.findIndex(sample)));
                    }

                    if(genre.equals("rock")){
                        player.startPlaying(rock.getSong(rock.findIndex(sample)));
                    }

                    if(genre.equals("country")){
                        player.startPlaying(country.getSong(country.findIndex(sample)));
                    }
                    break;
                case 11:
                    player.stop();
                    break;
            }
            System.out.println("----------");
        }
    }
}

