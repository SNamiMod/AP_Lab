/**
 * Provide basic playing of MP3 files via the javazoom library.
 * See http://www.javazoom.net/
 *
 * @author David J. Barnes and Michael K�lling. / Seyed Nami Modarressi
 * @version 2011.07.31 / v2
 */
public class MusicPlayer
{
    // The current player. It might be null.
    private boolean isPlaying;
    /**
     * Constructor for objects of class MusicFilePlayer
     */
    public MusicPlayer()
    {
        isPlaying = false;
    }
    /**
     * Start playing the given audio file.
     * The method returns once the playing has been started.
     * @param music The music to be played.
     */
    public void startPlaying(Music music)
    {
        System.out.println(music.getAddress() + " is playing...");
        isPlaying = true;
    }
    /**
     * stop playing song
     */
    public void stop()
    {
        System.out.println("player is stopped!");
        isPlaying = false;
    }
}