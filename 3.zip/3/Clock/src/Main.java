/**
 * this clock has Second now
 * @author Michael Kolling and David J. Barnes / Seyed Nami Modarressi (for add Seconds :) )
 * @version 2008.03.30 / V2
 */
public class Main {

    // "throws InterruptedException" is add automatically when i use sleep in program and it's not removable !!!

    public static void main(String[] args) throws InterruptedException {

        ClockDisplay clock = new ClockDisplay(java.time.LocalTime.now().getHour(), java.time.LocalTime.now().getMinute(), java.time.LocalTime.now().getSecond());

        for(int i = 0 ; i<10000;i++) {
            System.out.println(clock.getTime());
            Thread.sleep(1000);
            clock.timeTick();
        }

    }
}
