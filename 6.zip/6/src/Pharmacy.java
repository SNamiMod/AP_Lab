import java.util.ArrayList;

public class Pharmacy {

    private String name;

    public Pharmacy(String name){}

    public ArrayList<String> printMedicine(Patient p , Doctor d){}

}
