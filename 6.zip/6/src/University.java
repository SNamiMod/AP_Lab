import java.util.ArrayList;

public class University {

    private String name;
    private ArrayList<Patient> patients;

    public University(String name){}

    public void setPatients(Patient patient) {}

}
