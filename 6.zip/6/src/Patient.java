import java.util.ArrayList;

public class Patient {

    private String birthdate;
    private String first_insurance;
    private String second_insurance;
    private String degree;
    private String Gender;
    private String job;
    private String location;
    private ArrayList<MedicalRecord> records;
    private ArrayList<Doctor> doctors;

    public Patient(String birthdate , String first_insurance , String second_insurance,String degree,String gender,String job,String location){}

    public void setRecords(MedicalRecord record) {
    }

    public void setDoctors(Doctor doctor) {
    }

    public ArrayList<MedicalRecord> getRecords() {
    }

    public ArrayList<Doctor> getDoctors() {
    }

    public ArrayList<MedicalRecord> getKindRecords(String kind){}

    // getter methods


}
