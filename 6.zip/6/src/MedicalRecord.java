public class MedicalRecord {

    private String kind;
    private String description;
    private String diagnosis;
    private String degree;
    private String medicine;
    private String date;
    private String doctor;


    public MedicalRecord(String k , String d , String di , String de , String m , String date , String doctor){}

    // getter methods

}
