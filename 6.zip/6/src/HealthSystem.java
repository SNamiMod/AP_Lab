import java.util.ArrayList;

public class HealthSystem {

    private ArrayList<Patient> patients;
    private ArrayList<Doctor> doctors;
    private ArrayList<University> universities;
    private ArrayList<Pharmacy> pharmacies;


    public Patient getInformation(String name){}

    public void addRecord(Patient p , Doctor d){}

    public void addNewDoctorToPatient(Doctor d1,Doctor d2 , int mode){}

    public void addInformationToPharmacy(Pharmacy p , Patient pa){}

    public void addInformationToUniversity(University p , Patient pa){}


    //setter getter methods

}
