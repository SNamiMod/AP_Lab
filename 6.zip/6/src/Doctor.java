import java.util.ArrayList;
import java.util.HashMap;

public class Doctor {

    private HashMap<Patient, ArrayList<MedicalRecord>> records;

    public MedicalRecord addRecord(MedicalRecord m){}

    // getter setter methods

}
