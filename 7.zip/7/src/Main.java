/**
 * simple calculator
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 * */
import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) { System.err.println(ex.getMessage());
        }
        Calculator test = new Calculator();
    }
}
