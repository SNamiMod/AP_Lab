/**
 * this is design of calculator
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 * */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Calculator {

    private JFrame calcFrame;
    /**
     * create new window
    */
    public Calculator() {

        calcFrame = new JFrame("Calculator");
        calcFrame.setSize(300, 400);
        calcFrame.setLocation(550, 250);
        calcFrame.setLayout(null);
        calcFrame.setResizable(true);
        calcFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        draw();
        calcFrame.setVisible(true);

    }
    /**
     * draw screen and key
     */
    public void draw() {
        screen();
        key();
    }
    /**
     * add buttons to calculator and switch between pro mode and simple mode
     */
    public void key() {
        JTabbedPane mode = new JTabbedPane();
        mode.setBounds(0,100,300,250);
        JPanel base = new JPanel();
        base.setLocation(15, 100);
        base.setSize(200, 300);
        base.setLayout(new GridLayout(5, 4));
        for (int i = 0; i < 10; i++) {
            JButton b = new JButton(""+i);
            base.add(b);
        }
        JButton b0 = new JButton("+");
        base.add(b0);
        JButton b1 = new JButton("-");
        base.add(b1);
        JButton b2 = new JButton("*");
        base.add(b2);
        JButton b3 = new JButton("/");
        base.add(b3);
        JButton b4 = new JButton("%");
        base.add(b4);
        JButton b5 = new JButton("=");
        base.add(b5);
        JButton b6 = new JButton(".");
        base.add(b6);
        mode.add("Basic",base);

        // pro

        JPanel pro = new JPanel();
        pro.setLocation(15, 100);
        pro.setSize(200, 300);
        pro.setLayout(new GridLayout(4, 4));
        for (int i = 0; i < 10; i++) {
            JButton b = new JButton(""+i);
            pro.add(b);
        }
        JButton b00 = new JButton("+");
        pro.add(b00);
        JButton b11 = new JButton("-");
        pro.add(b11);
        JButton b22 = new JButton("*");
        pro.add(b22);
        JButton b33 = new JButton("/");
        pro.add(b33);
        JButton b44 = new JButton("%");
        pro.add(b44);
        JButton b112 = new JButton(".");
        pro.add(b112);
        JButton b55 = new JButton("sin");
        pro.add(b55);
        JButton b66 = new JButton("tan");
        pro.add(b66);
        JButton b77 = new JButton("exp");
        pro.add(b77);
        JButton b88 = new JButton("e");
        pro.add(b88);
        JButton b99 = new JButton("pi");
        pro.add(b99);
        JButton b111 = new JButton("shift");
        pro.add(b111);

        mode.add("pro",pro);

        calcFrame.add(mode);

        // switch between sin/cos - tan/cot - exp/ln

        b111.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == b111){
                    b55.setText("cos");
                    b66.setText("cot");
                    b77.setText("ln");
                }
            }
        });
        b55.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == b55){
                    b55.setText("sin");
                    b66.setText("tan");
                    b77.setText("exp");
                }
            }
        });
        b66.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == b66){
                    b55.setText("sin");
                    b66.setText("tan");
                    b77.setText("exp");
                }
            }
        });
        b77.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == b77){
                    b55.setText("sin");
                    b66.setText("tan");
                    b77.setText("exp");
                }
            }
        });


    }
    /**
     * draw screen and AC button
     */
    public void screen() {

        JFrame screen = new JFrame();
        JTextArea jta = new JTextArea();
        jta.setEditable(true);
        JScrollPane jsp = new JScrollPane(jta);
        jsp.setSize(200, 50);
        jsp.setLocation(20, 40);
        calcFrame.add(jsp);

        JButton clear = new JButton("AC");
        clear.setSize(50,50);
        clear.setLocation(225,40);
        calcFrame.add(clear);
    }

}


