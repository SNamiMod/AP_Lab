/**
 * this is the main class of the program ( faculty class )
 *  @author Seyed Nami Modarressi
 *  @version 1.0
 *  @since 2020-oct-10
 */
import java.util.ArrayList;

public class Faculty {

    public ArrayList<Group> groups = new ArrayList<Group>();
    public String name;
    public  int groupCounter;

    public Faculty(String name) {
        this.name = name;
        groupCounter=0;
    }
    /** This method is used to create new group
     * @param  gName This is name of the group
     */
    public void newGroup(String gName){

        Group g = new Group(gName);
        groups.add(g);
        groupCounter++;

    }
    /** This method is used to return groups of the faculty
     * @return is groups ( arraylist )
     */
    public ArrayList<Group> getGroups() {
        return groups;
    }
    /** This method is used to delete lab ( find lab with p )
     * @param  p This is the name of the group
     */
    public void deleteGroup(String p) {
        int index = 0;

        for (Group gRemove : groups) {

            if (gRemove.groupName.equals(p)) {

                break;

            }
            index++;

        }

        groups.remove(index);

    }

}
