/**
 * this class is the class of groups of the faculty like AI group or ...
 *  @author Seyed Nami Modarressi
 *  @version 1.0
 *  @since 2020-oct-10
 */
import java.util.ArrayList;

public class Group {

    public String groupName;
    public int labCounter;

    ArrayList<Lab> labs = new ArrayList<Lab>();

    public Group(String name) {

        groupName = name;
        labCounter = 0;

    }
    /** This method is used to create new lab
     * @param  p This is name of the lab professor
     * @param  c This is the capacity of the lab
     * @param  d This is day of the lab
     */
    public void newLab(String p, int c, String d) {

        Lab l = new Lab(p, c, d);
        labs.add(l);
        labCounter++;

    }
    /** This method is used to return labs of the group
     * @return is labs ( arraylist )
     */
    public ArrayList<Lab> getLabs() {
        return labs;
    }
    /** This method is used to delete lab ( find lab with p & d )
     * @param  p This is name of the lab professor
     * @param  d This is day of the lab
     */
    public void deleteLab(String p, String d) {
        int index = 0;

        for (Lab lRemove : labs) {

            if (lRemove.Professor.equals(p) && lRemove.getDay().equals(d)) {

                break;

            }
            index++;

        }

        labs.remove(index);

    }
    /** This method is used to print informations of the labs
     */
    public void print() {

        for (Lab l : labs) {

            System.out.println("**********");
            l.print();
            System.out.println("**********");
        }

    }

}
