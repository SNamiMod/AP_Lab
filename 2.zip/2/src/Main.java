/**
 * this program is just a  simple test for Classes
 *  @author Seyed Nami Modarressi
 *  @version 1.0
 *  @since 2020-oct-10
 */
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        Faculty F1 = new Faculty("CEIT");
        Student test = new Student("Nami","Modarressi","9733069");
        F1.newGroup("AI");
        ArrayList<Group> groups = new ArrayList<Group>();
        groups = F1.getGroups();
        groups.get(0).newLab("Nami",50,"Shanbe");
        groups.get(0).getLabs().get(0).enrollStudent(test);
        groups.get(0).getLabs().get(0).print();
    }

}
