/**
 *  this class has Labs information(s)
 *  @author Seyed Nami Modarressi
 *  @version 1.0
 *  @since 2020-oct-10
 */
public class Lab {

    public String Professor;
    private Student[] students;
    private int avg;
    private String day;
    private int capacity;
    private int currentSize;

    public Lab(String P , int cap, String d) {
        Professor = P;
        capacity = cap;
        day = d;
        students = new Student[capacity];
        avg = 0;
        currentSize = 0;
    }
    /** This method is used to add student to lab
     * @param std This is the student that we want to add to our lab
     */
    public void enrollStudent(Student std) {
        if (currentSize < capacity) {
            students[currentSize] = std;
            currentSize++;
        } else {
            System.out.println("Lab is full!!!");
        }
    }
    /** This method is used to Print Lab informations
     */
    public void print() {

        System.out.printf("Lab Professor : %s\nLab Capacity : %d\nCurrent Size : %d\n Student(s) :\n",Professor,capacity,currentSize);

        for(int i=0;i<currentSize;i++){
            students[i].print();
            System.out.println("");
        }
    }
    /** This method is used to return students of lab
     * @return is Students array
     */
    public Student[] getStudents() {
        return students;
    }
    /** This method is used to add students to lab
     * @param stu This is the students array that we want to add to our lab
     */
    public void setStudents(Student[] stu) {

        int flag = 0;

        for (int i = 0; i < stu.length; i++) {

            for (int j = 0; j < currentSize; j++) {

                if (stu[i].getFirstName().equals(students[j].getFirstName()) && stu[i].getLastName().equals(students[j].getLastName())) {
                    flag = 1;
                    break;
                }
            }

            if (flag == 0){
                enrollStudent(stu[i]);
            }
            else {
                flag = 0;
            }
        }
    }
    /** This method is used to return average
     * @return is average of grades
     */
    public int getAvg() {
        calculateAvg();
        return avg;
    }
    /** This method is used to calculate average of grades
     */
    public void calculateAvg() {
        for (int i = 0; i < currentSize; i++) {
            avg = avg + students[i].getGrade();
        }
        avg = avg / currentSize;
    }
    /** This method is used to return day of the lab
     * @return is day of the class (String)
     */
    public String getDay() {
        return day;
    }
    /** This method is used to set day of the lab
     * @param day This is the day of the lab
     */
    public void setDay(String day) {
        this.day=day;
    }
    /** This method is used to return capacity of the lab
     * @return is capacity of the lab(int)
     */
    public int getCapacity() {
        return capacity;
    }
    /** This method is used to set capacity of the lab
     * @param capacity This is the capacity of the lab
     */
    public void setCapacity(int capacity) {
        this.capacity=capacity;

    }
}