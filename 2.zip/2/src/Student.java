/**
 *  this class is the base of Faculty program ( students are great! :) )
 *  @author Seyed Nami Modarressi
 *  @version 1.0
 *  @since 2020-oct-10
 */

public class Student {

    private String firstName;
    private String lastName;
    private String id;
    private int grade;

    public Student(String fName, String lname, String sID) {

        firstName = fName;
        lastName = lname;
        if (sID.length() == 7) {
            id = sID;
        }else {
            id = "XXXXXXX";
        }
        grade = 0;
    }
    /** This method is used to return first name of student
    * @return is String
    */
    public String getFirstName() {
        return firstName;
    }
    /** This method is used to set first name of student
     * @param fName This is the First name of student
     */
    public void setFirstName(String fName) {
        firstName = fName;
    }
    /** This method is used to return last name of student
     * @return is String
     */
    public String getLastName() {
        return lastName;
    }
    /** This method is used to set last name of student
     * @param lName This is the last name of student
     */
    public void setLastName(String lName) {
        lastName = lName;
    }
    /** This method is used to set grade of student
     * @param Grade This is the last name of student
     */
    public void setGrade(int Grade){
        grade=Grade;
    }
    /** This method is used to return grade of student
     * @return is int
     */
    public int getGrade(){
        return grade;
    }
    /** This method is used to return ID of student
     * @return is String
     */
    public String getID(){
        return id;
    }
    /** This method is used to Print Student's informations
     */
    public void print() {
        System.out.println(lastName + ", student ID: " + id + ", grade: " + grade);
    }

}
