Part 2 of HW 5
