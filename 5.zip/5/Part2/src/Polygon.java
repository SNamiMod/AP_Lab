/**￼￼
 * polygon class
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 */
import java.util.ArrayList;

public class Polygon extends Shape {

    private int counter;
    private ArrayList<Integer> sides;
    /**￼￼
     * create new polygon from sides
     * @param s side(s)
     */
    public Polygon(int... s) {
        super();
        counter = 0;
        sides = new ArrayList<Integer>();
        for (int x : s) {
            sides.add(x);
            counter++;
        }
    }
    /**￼￼
     * @return sides of polygon
     */
    public ArrayList<Integer> getSides() {
        return sides;
    }
    /**￼￼
     * @return sides of polygon fpr printing
     */
    public String toString() {
        String s=" ";
        for (int i = 0; i < counter ;i++){
            s = s +" & " +sides.get(i);
        }
        return s;
    }

}
