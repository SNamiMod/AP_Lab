/**￼￼
 * triangle class
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 */
import java.util.ArrayList;

public class Triangle extends Polygon {
    /**￼￼
     * creat a triangle
     */
    public Triangle(int x, int y, int z) {
        super(x, y, z);
    }
    /**￼￼
     * print equilateral
     */
    public void isEquilateral() {
        ArrayList<Integer> sides = new ArrayList<>();
        sides = getSides();
        if (sides.get(0).equals(sides.get(1)) && sides.get(1).equals(sides.get(2))) {
            System.out.println("Yes");
        } else {
            System.out.println("No");
        }
    }
    /**￼￼
     * calculate perimeter of triangle
     * @return perimeter
     */
    public int calculatePerimeter() {
        ArrayList<Integer> sides = new ArrayList<>();
        sides = getSides();
        return (sides.get(0)+sides.get(1)+sides.get(2));
    }
    /**￼￼
     * calculate area of triangle
     * @return area
     */
    public int calculateArea() {
        ArrayList<Integer> sides = new ArrayList<>();
        sides = getSides();
        int s = calculatePerimeter()/2;
        return (int)(Math.sqrt(s*(s-sides.get(0))*(s-sides.get(1))*(s-sides.get(2))));
    }
    /**￼￼
     * draw triangle !
     */
    public void draw() {
        System.out.printf("Shape : Triangle # Area : %d # Perimeter : %d", calculateArea(), calculatePerimeter());
    }
    /**￼￼
     * return triangle information
     */
    public String toString() {

        return ("Triangle" + super.toString());

    }
}
