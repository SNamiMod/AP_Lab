/**￼￼
 * paint :)
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 */
public class Main {

    public static void main(String[] args) {

        Shape circle1 = new Circle(19);
        Shape circle2 = new Circle(3);
        Shape rect1 = new Rectangle(1,4,1,4);
        Shape tri1 = new Triangle(2,2,2);
        Paint paint = new Paint();
        paint.addShape(circle1);
        paint.addShape(circle2);
        paint.addShape(rect1);
        paint.addShape(tri1);
        paint.drawAll();
        paint.printAll();
        paint.describeEqualSides();

    }
}