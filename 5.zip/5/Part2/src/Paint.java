/**￼￼
 * paint class
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 */
import java.util.ArrayList;

public class Paint {

    ArrayList<Shape> shapes = new ArrayList<Shape>();
    /**￼￼
     * add shape to list
     * @param s shape
     */
    public void addShape(Shape s) {
        shapes.add(s);
    }
    /**￼￼
     * draw all shapes
     */
    public void drawAll() {
        for (Shape s :shapes){
            if (s instanceof Circle){
                ((Circle) s).draw();
            }
            if (s instanceof Rectangle){
                ((Rectangle) s).draw();
            }
            if (s instanceof Triangle){
                ((Triangle) s).draw();
            }
            System.out.println();
        }
    }
    /**￼￼
     * print shapes information
     */
    public void printAll() {
        for (Shape s :shapes){
            if (s instanceof Circle){
                System.out.println(((Circle) s).toString());
            }
            if (s instanceof Rectangle){
                System.out.println(((Rectangle) s).toString());
            }
            if (s instanceof Triangle){
                System.out.println(((Triangle) s).toString());
            }
        }
    }
    /**￼￼
     * checking isSquare and isEquilateral
     */
    public void describeEqualSides(){
        for (Shape s :shapes){
            if (s instanceof Rectangle){
                ((Rectangle) s).isSquare();
            }
            if (s instanceof Triangle){
                ((Triangle) s).isEquilateral();
            }
        }
    }

}
