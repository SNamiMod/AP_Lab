/**￼￼
 * rectangle class
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 */
import java.util.ArrayList;

public class Rectangle extends Polygon {
    /**￼￼
     * creat a rectangle
     */
    public Rectangle(int x, int y, int z, int q) {
        super(x, y, z, q);
    }
    /**￼￼
     * check square
     */
    public void isSquare() {
        ArrayList<Integer> sides = new ArrayList<>();
        sides = getSides();
        if (sides.get(0).equals(sides.get(1))) {
            System.out.println("Yes");
        } else {
            System.out.println("No");
        }
    }
    /**￼￼
     * @return perimeter of rectangle
     */
    public int calculatePerimeter() {
        ArrayList<Integer> sides = new ArrayList<>();
        sides = getSides();
        return (sides.get(0)+sides.get(1)+sides.get(2)+sides.get(3));
    }
    /**￼￼
     * @return area of rectangle
     */
    public int calculateArea() {
        ArrayList<Integer> sides = new ArrayList<>();
        sides = getSides();
        return (sides.get(0)*sides.get(1));
    }
    /**￼￼
     * draw rectangle !
     */
    public void draw() {
        System.out.printf("Shape : Triangle # Area : %d # Perimeter : %d", calculateArea(), calculatePerimeter());
    }
    /**￼￼
     * @return information of rectangle
     */
    public String toString() {

        return ("Rectangle" + super.toString());

    }

}
