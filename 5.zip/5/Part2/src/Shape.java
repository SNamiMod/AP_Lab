/**￼￼
 * Shape class
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 */
public class Shape {
    /**￼￼
     * @return 0
     * calculate perimeter of shape in other classes
     */
    public int calculatePerimeter() {
        return 0;
    }
    /**￼￼
     * @return 0
     * calculate area of shape in other classes
     */
    public int calculateArea() {
        return 0;
    }
    /**￼￼
     * draw in other classes
     */
    public void draw() {
        System.out.println("Draw");
    }
    /**￼￼
     * @return shape !
     */
    public String toString() {
        return "Shape";
    }

}
