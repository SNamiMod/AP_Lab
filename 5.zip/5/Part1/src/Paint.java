/**￼￼
 * paint class
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 */
import java.util.ArrayList;

public class Paint {

    private ArrayList<Circle> circles;
    private ArrayList<Triangle> triangles;
    private ArrayList<Rectangle> rectangles;
    /**￼￼
     * creat a paint
     */
    public Paint() {
        circles = new ArrayList<Circle>();
        triangles = new ArrayList<Triangle>();
        rectangles = new ArrayList<Rectangle>();
    }
    /**￼￼
     * add triangle
     */
    public void addTriangle(int x, int y, int z) {
        triangles.add(new Triangle(x, y, z));
    }
    /**￼￼
     * add rectangle
     */
    public void addRectangle(int x, int y, int z, int q) {
        rectangles.add(new Rectangle(x, y, z, q));
    }
    /**￼￼
     * add circle
     */
    public void addCircle(int r) {
        circles.add(new Circle(r));
    }
    /**￼￼
     * draw all shapes
     */
    public void drawAll() {
        for (Circle c : circles) {
            c.draw();
            System.out.println();
        }
        for (Triangle t : triangles) {
            t.draw();
            System.out.println();
        }
        System.out.println();
        for (Rectangle r : rectangles) {
            r.draw();
            System.out.println();
        }
    }
    /**￼￼
     * print shapes information
     */
    public void printAll() {
        for (Circle c : circles) {
            System.out.println(c.toString());
        }
        for (Triangle t : triangles) {
            System.out.println(t.toString());
        }
        System.out.println();
        for (Rectangle r : rectangles) {
            System.out.println(r.toString());
        }
    }
}
