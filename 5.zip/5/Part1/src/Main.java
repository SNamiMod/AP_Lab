/**￼￼
 * paint :)
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
*/
public class Main {

    public static void main(String[] args) {

        Circle circle1 = new Circle(19);
        Circle circle2 = new Circle(3);
        Rectangle rect1 = new Rectangle(1,4,1,4);
        Rectangle rect2 = new Rectangle(8,5,8,5);
        Rectangle rec3 = new Rectangle(6,6,6,6);
        Triangle tri1 = new Triangle(2,2,2);
        Triangle tri2 = new Triangle(4,4,6);
        Paint paint = new Paint();
        paint.addCircle(19);
        paint.addCircle(3);
        paint.addRectangle(1,4,1,4);
        paint.addRectangle(8,5,8,5);
        paint.addRectangle(6,6,6,6);
        paint.addTriangle(2,2,2);
        paint.addTriangle(4,4,6);
        paint.drawAll(); 
        paint.printAll();

    }
}
