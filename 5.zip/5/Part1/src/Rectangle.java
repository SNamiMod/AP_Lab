/**￼￼
 * rectangle class
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 */
import java.util.ArrayList;

public class Rectangle {
    private ArrayList<Integer> sides ;
    /**￼￼
     * creat a rectangle
     */
    public Rectangle(int x , int y , int z , int q){
        sides = new ArrayList<Integer>();
        sides.add(x);
        sides.add(y);
        sides.add(z);
        sides.add(q);
    }
    /**￼￼
     * @return sides
     */
    public ArrayList<Integer> getSides(){
        return sides;
    }
    /**￼￼
     * check square
     */
    public void isSquare(){
        if (sides.get(0).equals(sides.get(1)) && sides.get(1).equals(sides.get(2)) &&sides.get(1).equals(sides.get(3))){
            System.out.println("Yes");
        }else {
            System.out.println("No");
        }
    }
    /**￼￼
     * @return perimeter of rectangle
     */
    public int calculatePerimeter() {
        return (sides.get(0)+sides.get(1)+sides.get(2)+sides.get(3));
    }
    /**￼￼
     * @return area of rectangle
     */
    public int calculateArea() {
        return (sides.get(0)*sides.get(1));
    }
    /**￼￼
     * draw rectangle !
     */
    public void draw() {
        System.out.printf("Shape : Triangle # Area : %d # Perimeter : %d", calculateArea(), calculatePerimeter());
    }
    /**￼￼
     * @return information of rectangle
     */
    public String toString() {

        return ("Rectangle" + sides.get(0) +" &"+ sides.get(1) +" &"+ sides.get(2)+" &"+ sides.get(3));

    }
}
