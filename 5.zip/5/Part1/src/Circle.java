/**￼￼
 * circle class
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 */
public class Circle {

    private int radius;
    /**￼￼
     * creat a circle
     * @param r radius of circle
     */
    public Circle(int r) {
        radius = r;
    }
    /**￼￼
     * return radius
     * @return radius as int
     */
    public int getRadius() {
        return radius;
    }
    /**￼￼
     * calculate perimeter of circle
     * @return perimeter
     */
    public float calculatePerimeter() {
        return (float) (2 * radius * Math.PI);
    }
    /**￼￼
     * calculate area of circle
     * @return area
     */
    public float calculateArea() {
        return (float) (Math.PI * radius * radius);
    }
    /**￼￼
     * draw circle !
     */
    public void draw() {
        System.out.printf("Shape : Circle # Area : %f # Perimeter : %f", calculateArea(), calculatePerimeter());
    }
    /**￼￼
     * return circle information
     */
    public String toString() {

        return ("Circle" + radius);

    }

}
