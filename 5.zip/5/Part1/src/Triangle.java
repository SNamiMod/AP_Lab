/**￼￼
 * triangle class
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 */
import java.util.ArrayList;

public class Triangle {

   private  ArrayList<Integer> sides ;
    /**￼￼
     * creat a triangle
     */
    public Triangle(int x , int y , int z){
        sides = new ArrayList<Integer>();
        sides.add(x);
        sides.add(y);
        sides.add(z);
    }
    /**￼￼
     * @return sides
     */
    public ArrayList<Integer> getSides(){
        return sides;
    }
    /**￼￼
     * print equilateral
     */
    public void isEquilateral(){
        if (sides.get(0).equals(sides.get(1)) && sides.get(1).equals(sides.get(2))){
            System.out.println("Yes");
        }else {
            System.out.println("No");
        }
    }
    /**￼￼
     * calculate perimeter of triangle
     * @return perimeter
     */
    public int calculatePerimeter() {
        return (sides.get(0)+sides.get(1)+sides.get(2));
    }
    /**￼￼
     * calculate area of triangle
     * @return area
     */
    public double calculateArea() {
        int s = calculatePerimeter()/2;
        return (Math.sqrt(s*(s-sides.get(0))*(s-sides.get(1))*(s-sides.get(2))));
    }
    /**￼￼
     * draw triangle !
     */
    public void draw() {
        System.out.printf("Shape : Triangle # Area : %f # Perimeter : %d", calculateArea(), calculatePerimeter());
    }
    /**￼￼
     * return triangle information
     */
    public String toString() {

        return ("Triangle" + sides.get(0) +" &"+ sides.get(1) +" &"+ sides.get(2));

    }

}
