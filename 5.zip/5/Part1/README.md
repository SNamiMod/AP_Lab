Part 1
Part 1 of HW 5
