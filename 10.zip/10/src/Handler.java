/**
 * Handler Class for Server
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 */
import java.io.*;
import java.net.Socket;

class Handler implements Runnable
{
    private Socket connection;
    private int clientNumber;
    private BufferedReader input;
    private PrintWriter output;

    /**
     * Create new Handler
     * @param connection connection socket
     * @param clientNumber client number
     */
    public Handler(Socket connection, int clientNumber) {
        this.connection = connection;
        this.clientNumber = clientNumber;
        input = new BufferedReader();
        output = new PrintWriter();
    }

    /**
     * Handle server for Clients
     */
    @Override
    public void run() {
        try {
            System.out.println(clientNumber + "accepted ");
            OutputStream out = connection.getOutputStream();
            InputStream in = connection.getInputStream();
            while (true) {
                String code = input.readLine();
                if (code.equals("0")){
                    String username = input.readLine();
                    String password = input.readLine();
                    output.write();
                }
            }
            System.out.print("Closing connection for Client" + clientNumber + ".");

        } catch (Exception e2) {
            e2.printStackTrace();
        } finally {
            try {
                connection.close();
            } catch (IOException e3) {
                e3.printStackTrace();
            }
        }
    }
}