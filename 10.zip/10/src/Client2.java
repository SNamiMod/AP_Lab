/**
 * Client Class for test Server
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 */
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Client2 {

    public static void main(String[] args) {
        try (Socket client = new Socket("127.0.0.1", 5007)) {
            System.out.println("Connected");
            OutputStream out = client.getOutputStream();
            InputStream in = client.getInputStream();
            byte[] clientData = new byte[100000];
            Scanner scanner = new Scanner(System.in);
            while (true){
                System.out.print("Client : ");
                String massage = scanner.nextLine();
                if (massage.equals("exit")) {
                    break;
                }
                out.write(massage.getBytes());
                int read = in.read(clientData);
                System.out.println("Server : " + new String(clientData,0, read));
            }
            System.out.print("Closed");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}