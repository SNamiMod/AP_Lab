/**
 * Server Class
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 */

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {

    public static void main(String[] args) {
        ExecutorService pool = Executors.newCachedThreadPool();
        int counter = 0;
        try (ServerSocket welcomingSocket = new ServerSocket(5007)) {
            System.out.println("Server Started");
            // counter : max ( # clients )
            // if counter > 100 -> server closed
            while (counter < 100) {
                Socket connectionSocket = welcomingSocket.accept();
                counter+=1;
                pool.execute(new Handler(connectionSocket, counter));
            }
            System.out.print("Server Closed");
            pool.shutdown();
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}