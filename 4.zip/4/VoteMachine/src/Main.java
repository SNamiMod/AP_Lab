/**
 * this is simple voting manager program
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 * */
import ir.huri.jcal.JalaliCalendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {

        VotingSystem manager = new VotingSystem();
        int choice = 0;
        Scanner input = new Scanner(System.in);
        Date d = new Date();

        while (choice != 7) {

            System.out.println("---------------");
            System.out.println("1 ) add voting ");
            System.out.println("2 ) list of voting ");
            System.out.println("3 ) voting information ");
            System.out.println("4 ) vote");
            System.out.println("5 ) result of voting");
            System.out.println("6 ) add voting option ");
            System.out.println("7 ) exit ");
            choice = input.nextInt();
            System.out.println("---------------");

            if (choice == 1) {
                String s;
                String temp;
                int t;
                System.out.println("Enter Question :");
                temp = input.nextLine();
                s = input.nextLine();
                System.out.println("Enter Type of Voting :");
                t = input.nextInt();
                manager.createVoting(t, s);
            }
            if (choice == 2) {
                manager.printListOfVoting();
            }
            if (choice == 3) {
                int c;
                System.out.println("Enter Voting number :");
                c = input.nextInt();
                if (c > manager.getVotingList().get(c).getSize()) {
                    System.out.println("Invalid number !");
                } else {
                    manager.printVoting(c);
                }
            }
            if (choice == 4) {
                String temp;
                String fname;
                String lname;
                int c;
                String sample;
                int cc = -1;
                HashSet<String> votes = new HashSet<String>();

                System.out.println("Enter voting number :");
                c = input.nextInt();
                System.out.println("First name :");
                temp = input.nextLine();
                fname = input.nextLine();
                System.out.println("Last name :");
                lname = input.nextLine();
                if (c > manager.getSize()) {
                    System.out.println("Invalid number !");
                } else {
                    if (manager.getVotingList().get(c).getType() == 0) {
                        System.out.println("Enter Your Vote :");
                        votes.add(input.nextLine());
                    } else {
                        while (cc != 0) {
                            System.out.println("Enter Your Vote(s) {Enter 0 to End} :");
                            temp = input.nextLine();
                            sample = input.nextLine();
                            if (sample.equals("0")) {
                                cc = 0;
                            } else {
                                votes.add(sample);
                            }
                        }
                    }

                    JalaliCalendar jalaliDate = new JalaliCalendar(new GregorianCalendar(d.getYear(), d.getMonth(), d.getDay()));
                    String date = (jalaliDate.getYear() + "/" + jalaliDate.getMonth() + "/" + jalaliDate.getDay());
                    manager.vote(c, fname, lname, date, votes);
                }
            }
            if (choice == 5) {
                int c;
                System.out.println("Enter Voting number :");
                c = input.nextInt();
                if (c > manager.getSize()) {
                    System.out.println("Invalid number !");
                } else {
                    manager.printResult(c);
                }

            }
            if (choice == 6) {
                int c;
                String temp;
                String f;
                System.out.println("Enter voting number :");
                c = input.nextInt();
                System.out.println("Enter option :");
                temp = input.nextLine();
                f = input.nextLine();
                manager.getVotingList().get(c).createChoice(f);
            }
        }
    }
}
