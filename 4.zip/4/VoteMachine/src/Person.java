/**
 * this is person class
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 * */
public class Person {

    private String firstName;
    private String lastName;
    /**
     * create new person
     * */
    public Person(String fName , String lName){
        firstName = fName;
        lastName = lName;
    }
    /**
     * return first name of person
     * @return first name
     * */
    public String getFirstName(){
        return firstName;
    }
    /**
     * return last name of person
     * @return last name
     * */
    public String getLastName(){
        return lastName;
    }
    /**
     * return full name of person
     * @return full name
     * */
    public String toString(){
        return  (firstName+" "+lastName);
    }

}
