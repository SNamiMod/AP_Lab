/**
 * this is voting manager  class
 * in this class we can manage voting(s)
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 * */
import java.util.ArrayList;
import java.util.HashSet;

public class VotingSystem {

    private ArrayList<Voting> votingList;
    /**
     * create new list
     * */
    public VotingSystem() {
        votingList = new ArrayList<Voting>();
    }
    /**
     * print all questions
     * */
    public void printListOfVoting() {
        System.out.println("Voting(s) :");
        int counter = 1;
        for (Voting v : votingList) {
            System.out.printf("%d) %s \n", counter, v.getQuestion());
            counter++;
        }
    }
    /**
     * print result of voting
     * @param c voting that we want to print result of it
     * */
    public void printResult(int c) {
        votingList.get(c).printResult();
    }
    /**
     * return list
     * @return list of voting(s)
     * */
    public ArrayList<Voting> getVotingList(){
        return votingList;
    }
    /**
     * print information of voting
     * @param i voting number
     * */
    public void printVoting(int i) {
        votingList.get(i).printVote();
    }
    /**
     * create new voting
     * @param t type of voting
     * @param q question of voting
     * */
    public void createVoting(int t, String q) {
        votingList.add(new Voting(t, q));
        System.out.println("Added");
    }
    /**
     * add vote to voting
     * @param i voting number
     * @param fName first name of voter
     * @param lName last name of voter
     * @param date date of vote
     * @param c vote(s)
     * */
    public void vote(int i, String fName, String lName, String date, HashSet<String> c) {
        votingList.get(i).vote(new Person(fName, lName), date, c);
        System.out.println("Done");
    }
    /**
     * get list's size
     * */
    public int getSize(){
        return votingList.size();
    }
}
