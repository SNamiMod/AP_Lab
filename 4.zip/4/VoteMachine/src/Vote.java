/**
 * this is vote class
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 * */
public class Vote {

    private Person person;
    private String date;
    /**
     * create new vote
     * */
    public Vote(Person p , String d) {
        person = p;
        date = d;
    }
    /**
     * get person of vote
     * @return person
     * */
    public Person getPerson(){
        return person;
    }
    /**
     * get date of vote
     * @return date of vote
     * */
    public String getDate(){
        return date;
    }

}
