/**
 * this is voting  class
 * in this class we have voting program
 * @author Seyed Nami Modarressi
 * @version 1.0
 * @since 2020
 * */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class Voting {

    private int type;
    private String question;
    private ArrayList<Person> voters;
    private HashMap<String, HashSet<Vote>> choices;
    private ArrayList<String> choices_b = new ArrayList<String>();
    /**
     * create new voting
     * */
    public Voting(int t, String q) {
        type = t;
        question = q;
        voters = new ArrayList<Person>();
        choices = new HashMap<String, HashSet<Vote>>();
    }
    /**
     * get question of voting
     * @return question
     * */
    public String getQuestion() {
        return question;
    }
    /**
     * get voting voters !
     * @return voters
     * */
    public ArrayList<Person> getVoters() {
        return voters;
    }
    /**
     * create new option for voting
     * @param choice new option title
     * */
    public void createChoice(String choice) {
        boolean flag = false;
        for (String temp : choices_b) {
            if (temp.equals(choice)) {
                flag = true;
                break;
            }
        }
        if (flag == true) {
            System.out.println("This choice is exist");
        } else {
            choices_b.add(choice);
            choices.put(choice, new HashSet<Vote>());
            System.out.println("Added");
        }
    }
    /**
     * print result of voting
     * */
    public void printResult() {
        System.out.printf("Result of the { %s } is : \n", question);
        for (String sample : choices_b) {
            System.out.printf("%s : \n", sample);
            int counter = 1;
            for (Vote v : choices.get(sample)) {
                System.out.printf("%d) %s in %s\n", counter, v.toString(), v.getDate());
                counter++;
            }
        }
    }
    /**
     * get type of voting
     * @return type of voting
     * */
    public int getType() {
        return type;
    }
    /**
     * add vote to voting
     * @param p voter
     * @param d date of vote
     * @param c vote(s)
     * */
    public void vote(Person p, String d, HashSet<String> c) {

        for (String sample : c) {
            for (String temp : choices_b) {
                if (temp.equals(sample)) {
                    choices.get(temp).add(new Vote(p, d));
                    break;
                }
            }
        }
    }
    /**
     * get size of voting
     * @return size of voting
     * */
    public int getSize(){
        return choices_b.size();
    }
    /**
     * print question and options
     * */
    public void printVote(){
        int counter=1;
        System.out.printf("{ %s } \n",question);
        for (String sample : choices_b) {
            System.out.printf("%d) %s \n", counter, sample);
            counter++;
        }
    }
}