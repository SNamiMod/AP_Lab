Voting Machine
